<?php

namespace App\Http\Controllers;

use App\Asignacion;
use App\Cliente;
use App\Ejecutivo;
use App\Mail\NewCliente;
use App\Mail\NewSuscriptordeta;
use App\Mail\NewSuscriptorinfo;
use App\Mail\updateCaducidad2;
use App\Mail\updateCaducidad;
use App\Mail\updateSuscriptor;
use App\User;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Session;

class ClienteController extends Controller
{
        public function index()
        {
            // Retorna la vista para lista los clientes.
            return view('panel.cliente.index');
        }

        public function getClientes(Request $request)
        {
            // Retorna la lista paginada de clientes en formato JSON.
            $clientes = Cliente::with('user','ejecutivo')->orderBy('id','DESC')->paginate(6);
            return response()->json($clientes);
        }

        public function search(Request $request)
        {
            $texto = $request->text;
            // Retorna resultados de busqueda limitada en 6, formato JSON.
            $clientes = Cliente::join('users as u','clientes.user_id','=','u.id')
            ->where(DB::raw('concat(u.name," ",u.last_name)'),'like','%'.$texto.'%')
            ->orWhere('u.email','like', '%'.$texto.'%')
            ->with('user','ejecutivo')->select('clientes.*')->limit(6)->get();

            return response()->json($clientes);

        }

        public function store(Request $request)
        {

        	$validation = \Validator::make($request->all(),[
        	    'name'=>'required|string',
                'last_name'=>'required|string',
        	    'email'=>'required|email|unique:users',
        	    'password'=>'required|confirmed|min:6'
        	    ],[
        	      'email.unique'=>'El correo ingresado ya existe!'
        	    ]);
            if($validation->fails()){
                return response()->json(['errors'=>$validation->errors(),'status'=>422]);
            }else{

                //Insetar en la tabla users
                $user = new User();
                $user->name = $request->name;
                $user->last_name = $request->last_name;
                $user->email = $request->email;
                $user->password = bcrypt($request->password);
                $user->role_id = 5;
                $user->phone_number = $request->phone_number;
                $user->doc_number = $request->doc_number;
                $user->save();

                //Insertar en la tabla clientes
                $cliente = new Cliente();
                $cliente->empresa = $request->empresa;
                $cliente->user_id = $user->id;
                $cliente->medio = $request->medio;
                $cliente->save();

                //Vincular cliente con ejecutivo
                $cliente->ejecutivo()->attach($request->ejecutivo);

                //Enviando correo al cliente
                $data=[
                    'name'=> $user->fullName(),
                    'email'=> $user->email,
                    'password'=>$request->password
                ];
                Mail::to($user->email)
                ->send(new NewCliente($data));
                create_user_log('Agregó a '.strtoupper($user->fullName()).'('.$user->role->name.')');

                return response()->json(['message'=>'Registro exitoso','status'=>200]);
            }
            
        }

        /**
         * Update the specified resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @param  int  $id
         * @return \Illuminate\Http\Response
         */
        public function update(Request $request, $id)
        {
            $validation = \Validator::make($request->all(),[
                'name'=>'required|string',
                'last_name'=>'required|string',
                'email' => 'required|email|unique:users,email,'.$id.',id'
                ],[
                  'email.unique'=>'El correo ingresado ya existe!'
                ]);
            if($validation->fails()){
                return response()->json(['errors'=>$validation->errors(),'status'=>422]);
            }else{
               $user = User::find($id);

               $user->name = $request->name;
               $user->last_name = $request->last_name;
               $user->email = $request->email;
               $user->address = $request->address;
               $user->phone_number = $request->phone_number;
               $user->doc_number = $request->doc_number;
               $user->save();

               //actualizar tabla clientes
               $cliente = Cliente::where('user_id',$id)->first();
               
               //desvincular ejecutivo
               $cliente->ejecutivo()->detach();

               $cliente->empresa = $request->empresa;
               $cliente->medio = $request->medio;
               $cliente->status = $request->status;
               $cliente->save();

               //Vincular con el ejecutivo
               $cliente->ejecutivo()->attach($request->ejecutivo);

               create_user_log('Actualizó los datos de '.strtoupper($user->fullName()).'('.$user->role->name.')');

               return response()->json(['message'=>'Actualización exitosa','status'=>200]); 
            }
        }
        public function frmConvert($id)
        {
            
            $user = User::find($id);
            $ejecutivos = Ejecutivo::all();
            return view('panel.cliente.frmconvert',compact('user','ejecutivos'));
        }
        public function convertStore(Request $request, $id)
        {
            $user = User::find($id);

            $asignacion = Asignacion::where('suscriptor_id','=',$id)->first();

            $cliente = Cliente::create([
                'empresa'   =>  $request->empresa,
                'user_id'   =>  $user->id,
                'medio'     => $request->medio
            ]);

            $cliente->ejecutivo()->attach($request->ejecutivo);


            $user->role_id = 5;
            $user->save();

            $asignacion->is_confirmed = 1;
            $asignacion->save();

            Session::flash('msg','Registro exitoso!');
            return redirect()->route('mybandeja',Auth()->user()->id);
            
        }
}

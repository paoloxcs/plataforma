@extends('layouts.app')
@section('titulo','Cursos')
@section('content')
<div class="container">
    <ol class="breadcrumb">
      <li class="breadcrumb-item active">
        <i class="fa fa-list-ol"></i> Editar curso
      </li>
    </ol>
    <div class="panel panel-success">
        
        <form action="{{route('curso.update',$curso->id)}}" method="POST" enctype="multipart/form-data">
        {{ csrf_field() }}
      
        <div class="modal-body">
              <div class="row">
                <div class="col-xs-12 col-md-8">
                    <div class="form-group">
                        <label for="titulo">Título</label>
                        <input type="text" class="form-control" name="titulo" placeholder="Título aquí" autofocus value="{{old('titulo',$curso->titulo)}}">
                     </div>
                     <div class="form-group">
                         <label for="infoadd">Descripción</label>
                         <textarea name="descripcion"  cols="30" rows="5" class="form-control" placeholder="Ingrese descripción">{{old('descripcion',$curso->descripcion)}}</textarea>
                     </div>
                     <div class="form-group">
                         <label for="infoadd">Información</label>
                         <textarea name="informacion"  cols="30" rows="5" class="form-control" placeholder="Ingrese información">{{old('informacion',$curso->informacion)}}</textarea>
                     </div>
                </div>
                <div class="col-xs-12 col-md-3">
                    <div class="form-group">
                        <label for="">Elegir rubro</label>
                        <select name="rubro_id"  class="form-control rubros">
                          <option selected disabled><< Seleccione >></option>
                          @foreach($rubros as  $rubro)
                          @if($curso->rubro_id == $rubro->idrubro)
                          <option selected value="{{$rubro->idrubro}}">{{$rubro->nombrerubro}}</option>
                          @else
                          <option value="{{$rubro->idrubro}}">{{$rubro->nombrerubro}}</option>
                          @endif
                          @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Elegir Docente</label>
                        <select name="autor_id"  class="form-control rubros">
                          <option selected disabled><< Seleccione >></option>
                          @foreach($autores as  $autor)
                          @if($curso->autor_id == $autor->idautor)
                          <option selected value="{{$autor->idautor}}">{{$autor->nombre}}</option>
                          @else
                          <option value="{{$autor->idautor}}">{{$autor->nombre}}</option>
                          @endif
                          @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="titulo">Precio</label>
                        <input type="number" class="form-control" name="precio" placeholder="Precio aquí" autofocus value="{{old('precio',$curso->precio)}}">
                     </div>

                     <div class="form-group">
                        <label for="titulo">Promoción</label>
                        <input type="number" class="form-control" name="promocion" placeholder="Promoción aquí" autofocus value="{{old('promocion',$curso->promocion)}}">
                     </div>

                     <div class="form-group">
                        <label for="">Estado</label>
                        <select name="estado"  class="form-control rubros">
                           @if($curso->estado == 1)
                            <option selected value="1">Activo</option>
                            <option value="0">Inactivo</option>
                            @elseif($curso->estado == 0)
                            <option  value="1">Activo</option>
                            <option selected value="0">Inactivo</option>

                            @endif
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="titulo">Fecha</label>
                        <input type="date" class="form-control" name="fecha" autofocus value="{{old('fecha',$curso->fecha)}}">
                     </div>

                     <div class="form-group">
                        <label for="titulo">Fecha expiración</label>
                        <input type="date" class="form-control" name="expira" autofocus value="{{old('expira',$curso->expira)}}">
                     </div>

                    
                </div>
              </div>

              <div class="row">
                
                <div class="col-xs-12 col-md-4">
                   <div class="form-group">
                      <label for="">Subir Portada</label>
                      <input type="file" accept="image/*" name="portada" >
                  </div>
                </div>
                
              </div>
              
              </div>
              <div class="form-group flex-row-reverse ">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Guardar</button>
                <a href="javascript:history.back();" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Regresar</a>
              </div>
            </div>   
       
          
        
      </form>
    </div>
   
</div>

@endsection
@section('extra_scripts')

@endsection
@extends('layouts.front')
@section('titulo')
{{$curso->titulo}}
@endsection
@section('content')
<div class="container" itemscope itemtype="http://schema.org/VideoObject">
  <div class="row mt-4">
    <div class="col-xs-12 col-md-8">
      <div class="embed-responsive embed-responsive-16by9">                            
        <img class="embed-responsive-item" src="{{asset('imgCurso/'.$curso->url_portada)}}" ></img>
      </div>

      <div class="preview-video">
        <h1 class="title" itemprop="name">{{$curso->titulo}} 
                 </h1>
                 <div class="row mt-4">
                  <div class="col-xs-12 col-md-6">
                    <p>Inicia el &nbsp;<span><i class="fa fa-calendar"></i> <strong>{{date('d/m/Y',strtotime($curso->fecha))}}</strong></span></p>
            <p>Clases: <strong>{{$curso->countClases()}}</strong></p>
            <div class="none">{{$a=($curso->rubro->slug)}}</div> 
                    
                  </div>
                  <div class="col-xs-12 col-md-6">
                    <ul class="list-group">
                      <li class="list-group-item"><span class="badge badge-secondary">{{$curso->countAlumnos()}}</span> Alumnos</li>
                      {{--<li class="list-group-item"><span class="badge badge-secondary"></span> Me gusta</li>
                      <li class="list-group-item"><span class="badge badge-secondary"></span>  Comentarios</li>--}}
                    </ul>
                  </div>
                 </div>
        <h4>Descripción</h4>
        <p class="mt-3">
          {{$curso->descripcion}}
        </p>
      </div>
      
    </div>
    <div class="col-xs-12 col-md-4">
      <meta itemprop="thumbnail" content="{{$curso->url_portada}}" />
      <meta itemprop="thumbnailUrl" content="{{asset('imgCurso/'.$curso->url_portada)}}" />
      <meta itemprop="uploadDate" content="{{$curso->fecha}}" />

      @if(Auth()->user())
              
        @if(Auth()->user()->SuscriptorCursos($curso->id))
          <h4>Clases Disponibles</h4>
          <ul class="list-group curso_ul">
            <li class="list-group-item active">Contenido</li>
            @foreach($clases as $clase)
            <a href="{{url('clases/'.$curso->slug)}}" style="text-decoration: none;color:black" ><li class="list-group-item">{{$clase->titulo}} <i class="fas fa-chevron-right"></i></li></a>
            @endforeach
          </ul>

          @foreach($evaluacion_user as $evaluser)
          @if($evaluser->user_id == Auth()->user()->id)
            <a href="{{url('resultado/'.$curso->slug)}}" style="color:white;text-decoration: none;"><div class="preview-info mb-4 bg-success">
                <p class="subtitle mt-3 " style="font-size: 30px;font-weight: 500;">Ver resultados de tu evaluación</p>
                
                <p class="subtitle mt-3" style="font-size: 65px;"><i class="far fa-file-alt "></i></p>
              </div>
            </a>
          @else

          <a href="{{url('evaluacion/'.$curso->slug)}}" style="color:white;text-decoration: none;"><div class="preview-info mb-4">
              <p class="subtitle mt-3" style="font-size: 30px;font-weight: 500;">Realiza tu evaluación</p>
              
              <p class="subtitle mt-3" style="font-size: 65px;"><i class="far fa-file-alt"></i></p>
            </div>
          </a>
          @endif
          @endforeach
        @else

          <h4>Este curso consta de {{$curso->countClases()}} clases</h4>
            <ul class="list-group curso_ul">
              <li class="list-group-item active">Contenido</li>
              @foreach($clases as $clase)
              <li class="list-group-item">{{$clase->titulo}}</li>
              @endforeach
            </ul>

            <div class="preview-info mb-4">
              <p class="subtitle mt-3" >Participa en este curso</p>
              <h1 class="title-info" style="font-size: 35px">S/. {{$curso->promocion}}.00</h1>
              <p class="subtitle mt-3" style="font-size: 15px;text-decoration: line-through; ">Precio real S/.  {{$curso->precio}}.00</p>
              <div class="mt-2-text-center">
                @if (!\Auth::guest()) 
                <button type="button" id="buyButton1"  class="btn btn-green">Comprar</buttom>
                
                @else
                <a href="{{route('login')}}" class="btn btn-green">Comprar</a>
                @endif

              </div>
            </div>
        @endif

      @else
        <h4>Este curso consta de {{$curso->countClases()}} clases</h4>
            <ul class="list-group curso_ul">
              <li class="list-group-item active">Contenido</li>
              @foreach($clases as $clase)
              <li class="list-group-item">{{$clase->titulo}}</li>
              @endforeach
            </ul>

            <div class="preview-info mb-4">
              <p class="subtitle mt-3" >Participa en este curso</p>
              <h1 class="title-info" style="font-size: 35px">S/. {{$curso->promocion}}.00</h1>
              <p class="subtitle mt-3" style="font-size: 15px;text-decoration: line-through; ">Precio real S/.  {{$curso->precio}}.00</p>
              <div class="mt-2-text-center">
                @if (!\Auth::guest()) 
                <button type="button" id="buyButton1"  class="btn btn-green">Comprar</buttom>
                
                @else
                <a href="{{route('login')}}" class="btn btn-green">Comprar</a>
                @endif

              </div>
            </div>

      @endif


      {{--<h4>Este curso consta de {{$curso->countClases()}} clases</h4>
      <ul class="list-group curso_ul">
        <li class="list-group-item active">Contenido</li>
        @foreach($clases as $clase)
        <li class="list-group-item">{{$clase->titulo}}</li>
        @endforeach
      </ul>

      <div class="preview-info mb-4">
        <p class="subtitle mt-3" >Participa en este curso</p>
        <h1 class="title-info" style="font-size: 35px">S/. {{$curso->promocion}}.00</h1>
        <p class="subtitle mt-3" style="font-size: 15px;text-decoration: line-through; ">Precio real S/.  {{$curso->precio}}.00</p>
        <div class="mt-2-text-center">
          @if (!\Auth::guest()) 
          <button type="button" id="buyButton1"  class="btn btn-green">Comprar</buttom>
          
          @else
          <a href="{{route('login')}}" class="btn btn-green">Comprar</a>
          @endif

        </div>
      </div>--}}


      
      
    </div>
  </div>
</div>
@endsection
@section('script-extra')
<!-- Incluyendo .js de Culqi Checkout-->
<script src="https://checkout.culqi.com/js/v3"></script>
<!-- Configurando el checkout-->
<script>

    {{-- Culqi.publicKey = 'pk_live_OhE2jDzFFYhPEkjy';--}}
      Culqi.publicKey = 'pk_test_sXUCiBUCfkPNteTd';
</script>
<script src="{{asset('js/waitMe.min.js')}}"></script>
<script>


  $('#buyButton1').on('click', function(e) {

      // Abre el formulario con las opciones de Culqi.settings
      Culqi.open();
      e.preventDefault();

  });
  

  /*Configurando el checkout*/
      Culqi.settings({
          title: 'PARTICIPACIÓN',
          currency: 'PEN',
          description: 'Participación - {{$curso->titulo}}',
          amount: ({{$curso->promocion}} * 100)
      });

  function culqi() {

      if(Culqi.token) { // ¡Token creado exitosamente!

        $(document).ajaxStart(function(){
          run_waitMe();
        });
          
          var tokencsrf = '{{ csrf_token()}}';

          var datos = {
            tokenId : Culqi.token.id,
              CursoId : '{{$curso->id}}',
          };

          /*var email = Culqi.token.email;*/

          var ruta = "{{url('suscripcioncurso')}}";

          $.ajax({
            type: 'POST',
            headers: {'X-CSRF-TOKEN': tokencsrf},
            url : ruta,
            dataType: 'json',
            data: datos,
            success: function(data) {
              
              var result = "";

              if(data.constructor == String){
                  result = JSON.parse(data);
              }
              if(data.constructor == Object){
                  result = JSON.parse(JSON.stringify(data));
              }

              if(result.object === 'charge'){
                show_message(result.outcome.user_message,'alert-success','charge');
                console.log(result.outcome.merchant_message);
              }

              if(result.object === 'error'){
                if (!result.user_message) {
                  show_message(result.merchant_message,'alert-warning','error');
                }else{
                  show_message(result.user_message,'alert-warning','error');
                }
                  console.log(result.merchant_message);
              }

            },
            error: function(error) {
              show_message(error,'alert-danger','error');
              console.log(error);
            }
          });

      }else{ // ¡Hubo algún problema!
          // Mostramos JSON de objeto error en consola
          console.log(Culqi.error);
          console.log(Culqi.error.merchant_message);

          show_message(Culqi.error.user_message,'alert-danger','error');
      }
  }


function run_waitMe(){
  $('body').waitMe({
    effect: 'orbit',
    text: 'Procesando pago...',
    bg: 'rgba(255,255,255,0.7)',
    color:'#339954'
  });
}

function show_message(message,type_alert,estado){
  $('#mensajepago').empty();

  $("#mensajepago").append(`
      <div class="bg-content">
        <div class="col-xs-12 col-md-4 mx-auto">
          <div class="card">
            <div class="card-header">
              <div class="card-title text-center">Mensaje</div>
            </div>
            <div class="card-body">
              <div id="alert" class="alert ${type_alert} alert-dismissible" role="alert">
                ${message}
              </div>
            </div>
            <div class="card-footer">
            ${estado =='charge' ? '<a href="/profile/suscription" class="btn btn-success btn-block">Ver mis cursos</a>' :'<a href="/" class="btn btn-secondary btn-block">Aceptar</a>'}
            </div>
          </div>
        </div>
      </div>
    `);
  
  $('body').waitMe('hide');
  $('.bg-response').show();
  
}

</script>
@endsection
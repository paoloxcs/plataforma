@extends('layouts.front')
@section('titulo')
@if($slug =='construccion')
Cursos sobre construcción
@elseif($slug == 'mineria')
cursos sobre minería
@else
cursos sobre arquitectura
@endif
@endsection
@section('content')
<div class="container">
  @if($slug =='construccion')
  <div class="none">{{$a='construccion'}}</div>
  @elseif($slug == 'mineria')
 <div class="none">{{$a='mineria'}}</div> 
  @else
  <div class="none">{{$a='arquitectura'}}</div>
  @endif

  <hgroup>
    <h2 class="title-custom text-center">CURSOS DISPONIBLES</h2>
    <p class="text-center" style="margin-top:1%;">Certifícate con los cursos técnicos disponibles que tenemos para ti.</p>


  </hgroup>
  <div class="row">
        @if($slug =='construccion')
          <div class="none">{{$a='construccion'}}</div>
          <h5 class="text-center mx-auto">CONSTRUCCIÓN</h5>

        @elseif($slug == 'mineria')
          <div class="none">{{$a='mineria'}}</div> 
          <h5 class="text-center mx-auto">MINERÍA</h5>
        @else
          <div class="none">{{$a='arquitectura'}}</div>
          <h5 class="text-center mx-auto">ARQUITECTURA</h5>
        @endif
        

     <div class="col-xs-12 col-md-12">
      <ul class="video-list ">
        @foreach($cursos as $curso)
          <li class="video-item ">
            
                <a href="{{url('curso/'.$curso->slug)}}" class="video-item-cover video-player">
              <picture width="278" height="156">
                <img src="{{asset('imgCurso/'.$curso->url_portada)}}" alt="{{$curso->titulo}}">
               {{-- <img src="https://plataforma.constructivo.com/posts/{{$curso->image}}" alt=""> --}}
              </picture>
              {{--<span class="play">
                <i class="fa fa-play"></i>
              </span>--}}
              
               </a>

            <ul class="video-mini-states">
              @if(Auth()->user())
              
               @if(Auth()->user()->SuscriptorCursos($curso->id))
                  <a style="text-decoration: none" href="{{url('clases/'.$curso->slug)}}">
                    <li class="video-duration">
                    <strong><i  class="fas fa-tv" ></i></strong>  {{$curso->countClases()}} Clases
                    </li>
                  </a> 
                @else
                  <li class="video-duration">
                    <strong><i  class="fas fa-tv" ></i></strong>  {{$curso->countClases()}} Clases
                    </li>
                @endif

              @else
              <li class="video-duration">
                    <strong><i  class="fas fa-tv" ></i></strong>  {{$curso->countClases()}} Clases
                    </li>
              @endif


              <li class="views">
               {{$curso->countAlumnos()}}  alumnos
              </li>
            </ul>
            <div class="video-item-details">
              <h3 class="video-item-title">
               
              <a href="{{url('curso/'.$curso->slug)}}">{{$curso->titulo}}</a>
           
                
              </h3>
              <div class="mt-1 mb-1">
                <span class="tag-post">{{$curso->rubro->nombrerubro}}</span>
                 <div class="none">{{$a=($curso->rubro->slug)}}</div>
              </div>
               @if(Auth()->user())
              
               @if(Auth()->user()->SuscriptorCursos($curso->id))
              {{--<div class="mt-1 mb-1">
                <p class="promocion">Participando</p>
              </div>--}}
              @else
                <div class="mt-1 mb-1">
                <p class="precio">S/. {{$curso->precio}}.00</p>
                <p class="promocion">S/. {{$curso->promocion}}.00</p>
                </div>
              @endif

              @else
                <div class="mt-1 mb-1">
                <p class="precio">S/. {{$curso->precio}}.00</p>
                <p class="promocion">S/. {{$curso->promocion}}.00</p>
                </div>
              @endif

              <div class="video-author">
                  <div class="author-pic">
                    <img src="{{asset('posts/'.$curso->autor->imagen)}}" alt="">
                      {{-- <img src="https://plataforma.constructivo.com/posts/{{$curso->autor->imagen}}" alt=""> --}}
                  </div>
                  <strong class="author-name"><a href="{{url('videos/autor/'.$curso->autor->slug)}}">{{$curso->autor->nombre}}</a></strong>
              </div>

                 @if(Auth()->user())
               @if(Auth()->user()->SuscriptorCursos($curso->id))
                <p class="text-center"><a class="btn_vercurso" href="{{url('curso/'.$curso->slug)}}">Ver Curso</a></p>
                @else
                @endif
                @else
                @endif

            </div>
          </li>
        @endforeach
      </ul>
    </div>
  </div>
  <div class="row d-flex justify-content-center">
  
  </div>
</div>
@endsection
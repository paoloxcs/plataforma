@extends('layouts.front')
@section('titulo')
{{$clase->titulo}}
@endsection
@section('content')
<div class="container">
  
  <hgroup>
    <div class="none">{{$a=$rubro->slug}}</div> 
    <h2 class="text-center"> {{$clase->titulo}}</h2>
  </hgroup>
  
  <div class="row">
    <ul class="revista-list d-flex justify-content-center flex-wrap">

      <li class="col-xs-12 col-md-8 col-lg-10">
        <div class="revista-item">
          <div class="revista-item-header">
            <div class="content-img">
              <a href="{{route('getclase',$clase->slug)}}">
                {{-- <img src="https://plataforma.constructivo.com/revistas/{{$revista->perspectiva}}" alt=""> --}}
                <img src="{{asset('imgCurso/'.$clase->url_portada)}}" class="img-fluid" alt="">
              </a>
            </div>
          </div>
          <div class="revista-item-details">
            {{--<p class="revista-fecha">{{$revista->fecha}} - {{$revista->año}}</p>--}}
            <hr>
           {{--}} @if (!\Auth::guest()) 
            <a href="{{url('revista/'.$revista->medio.'/'.$revista->nro)}}" class="btn btn-outline-blue btn-block">comparar</a>
            @else
            <a href="{{route('planes1')}}" class="btn btn-outline-blue btn-block">comparar</a>
            @endif--}}

          </div>
        </div>
      </li>

    </ul>
  </div>

   <hgroup>
    <h3 class="title-custom text-center">Materiales de apoyo</h3>
  </hgroup>
  <div class="row mb-3">
    <ul class="list-group list-art col-md-12">
      @foreach($materiales as $art)
      <li class="list-group-item art-item">
        <div class="row d-flex">
          <div class="col-md-1 d-none d-lg-block art-item-img">
            <img src="{{asset('images/pdf-icon.png')}}" alt="">
          </div>
          <div class="col-xs-12 col-md-11 art-item-content">
            <div class="art-titulo">
              <a href="{{asset('pdfClase/'.$art->url_file)}}" download="{{$art->nombre_documento}}">{{$art->nombre_documento}}</a> <span class="badge badge-warning"></span>
            </div>
            <div class="art-metadata mt-3">
              
              <div class="art-actions">
                <span><i class="fa fa-calendar"></i>{{date('d/m/Y',strtotime($art->created_at))}}</span>
                <span><i class="fa fa-download"></i>{{$art->peso}}</span>
              </div>
            </div>
          </div>
        </div>
      </li>
      @endforeach
      
    </ul>
    
  </div>

  <div class="row d-flex justify-content-center">
  
  </div>
</div>
@endsection